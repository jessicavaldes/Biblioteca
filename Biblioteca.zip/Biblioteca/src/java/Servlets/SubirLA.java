package Servlets;

import Clases.LibrosB;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SubirLA extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        LibrosB p = new LibrosB();
        
        String nombreLibro = request.getParameter("nombreLibro");
        String Autor = request.getParameter("Autor");
        String Genero = request.getParameter("Genero");
        String Anio = request.getParameter("Anio");
        String Editorial = request.getParameter("Editorial");
        String idLibro = request.getParameter("idLibro");
        String idPersona = request.getParameter("idPersona");
        
        try {
            p.SubirLb(nombreLibro, Autor, Editorial, Genero, Anio, idPersona, idLibro);
        } catch (SQLException ex) {
            ex.getMessage();
        }finally{
            response.sendRedirect("index.jsp");
        }
    }
}